# 中物院毕业论文模板以及答辩 beamer 模板

作者：李昂

邮箱：ang.li.1997@icloud.com

日期：2024年6月11日

致谢：所依赖的前模板的不具名作者

Note：如果这个模板帮助到了您，欢迎自愿在致谢中进行感谢

Note：如果这个论文中的工作对您有启发，欢迎引用我们的文章

## 使用方式

1. 下载 zip 包 `phdthesis_and_beamer_gscaep.zip`
2. 使用 git clone

github 仓库地址: https://github.com/AngLi-China/phdthesis_and_beamer_gscaep.git

coding 仓库地址: https://only842170670.coding.net/public/person/phdthesis_and_beamer_gscaep/git/files

coding 仓库 clone 专用地址: https://e.coding.net/only842170670/person/phdthesis_and_beamer_gscaep.git

## 中物院毕业答辩 beamer 模板

参考 `phdthesis/ReadMe.md`

## 中物院毕业答辩 beamer 模板

参考 `slides/ReadMe.md`